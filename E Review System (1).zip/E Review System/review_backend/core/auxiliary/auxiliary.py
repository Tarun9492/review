from rest_framework.response import Response

def get_custom_response(success=False, message='something went wrong', data=None, status=400):
    response = {
        'success': success,
        'message': message,
        'data': data
    }
    return Response(response, status=status)
