from email.policy import default
from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.


class UserAccount(AbstractUser):
    username = models.CharField(unique=True, max_length=255)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.EmailField(unique=True, max_length=255)
    password = models.CharField(max_length=255)
    created_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email

class ProductReview(models.Model):
    user = models.ForeignKey(UserAccount, on_delete=models.CASCADE, null=False)
    product = models.CharField(max_length=255)
    company = models.CharField(max_length=255)
    purchase_date = models.CharField(max_length=255)
    description = models.TextField()
    price = models.CharField(max_length=10)
    user_name = models.CharField(max_length=255)
    review = models.CharField(max_length=1)

    def __str__(self):
        return self.name