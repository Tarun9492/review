
from django.urls import path
from core import views


urlpatterns = [
    path('login', views.login),
    path('signup', views.signup),
    path('get-user/<str:pk>', views.getUser),
    #path('get-product/<str:pk>', views.getProduct),
    path('get-reviews', views.getReviews),
    path('create-review', views.createReview),
]