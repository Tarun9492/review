import json
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from core.serializers import UserAccountSerializer, ProductReviewSerializer

from rest_framework.decorators import api_view, permission_classes
from rest_framework import permissions
from core.auxiliary.auxiliary import get_custom_response
from django.contrib.auth.hashers import check_password, make_password
from rest_framework_simplejwt.tokens import RefreshToken
from core.models import UserAccount, ProductReview
from datetime import datetime

@csrf_exempt
@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def login(request):
    body = json.loads(request.body)
    email = body['email']
    password = body['password']
    user_verified = False
    
    try:
        user = UserAccount.objects.get(email=email)
        if (password == user.password) or (check_password(password, user.password)):
            user_verified = True
    except Exception as _e:
        response = get_custom_response(success=False, message="No User Found with these credentials", status=401)
        return response
    
    if user_verified:
        refresh = RefreshToken.for_user(user)
        data = {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'admin': user.is_superuser,
            'user_id': user.id
        }
        response = get_custom_response(success=True, message="Successfull", data=data, status=200)
    else:
        response = get_custom_response(success=False, message="Wrong Credentials", status=401)

    return response


@csrf_exempt
@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def signup(request):
    body = json.loads(request.body)
    print(body)
    try:
        email = body['email']
    except:
        response = get_custom_response(success=False, message="Email not passed in body", status=401)
        return response
    
    try:
        user = UserAccount.objects.get(email=email)
        response = get_custom_response(success=False, message="Email id already present", status=401)
        return response
    except UserAccount.DoesNotExist:
        pass

    _d = {}
    for col in ['first_name', 'second_name', 'email', 'password']:
        if (col in body) and (col != 'password'):
            _d[col] = body[col]
        if (col in body) and (col == 'password'):
            _d[col] = make_password(body[col])
    _d['username'] = body['email']

    user = UserAccount.objects.create(**_d)
    response = get_custom_response(success=True, message="Successfull", data=UserAccountSerializer(user).data, status=200)
    return response


@csrf_exempt
@api_view(['GET'])
def getUser(request, pk):
    try:
        user = UserAccount.objects.get(pk=pk)
    except Exception as _e:
        response = get_custom_response(success=False, message="No User Found with these credentials", status=401)
        return response
        
    response = get_custom_response(success=True, message="Successfull", data=UserAccountSerializer(user).data, status=200)
    return response


@csrf_exempt
@api_view(['GET'])
def getReviews(request):
    reviews = ProductReview.objects.all()
    reviews_data = ProductReviewSerializer(reviews, many=True).data
    
    response = get_custom_response(success=True, message="Successfull", data=reviews_data, status=200)
    return response


# @csrf_exempt
# @api_view(['GET'])
# def getProduct(request, pk):
#     product = Product.objects.filter(id = pk)
#     product_data = ProductSerializer(product, many=True).data[0]

#     reviews = Review.objects.filter(product__id=pk)
#     reviews_data = ReviewSerializer(reviews, many=True).data
    
#     response = get_custom_response(success=True, message="Successfull", data={
#         'product': product_data,
#         'reviews': reviews_data
#     }, status=200)
#     return response


@csrf_exempt
@api_view(['POST'])
def createReview(request):
    body = json.loads(request.body)
    try:
        user = UserAccount.objects.get(email=request.user)
    except:
        response = get_custom_response(success=True, message="User not allowed", status=401)
        return response

    try:
        review = ProductReview.objects.create(
            user=user,
            product=body['product'],
            company=body['company'],
            purchase_date=body['purchase_date'],
            description=body['description'],
            price=body['price'],
            user_name=body['user_name'],
            review=body['review'],
        )
        review_data = ProductReviewSerializer(review).data
        response = get_custom_response(success=True, message="Successfull", data=review_data, status=200)
    except Exception as e:
        response = get_custom_response(success=True, message="Error in creating review", status=400)

    return response