import React, { useState } from "react";
import "./App.css";
import Dashboard from "./components/Dashboard/dashboard";
import Auth from "./components/Auth/auth";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Signup from "./components/Signup/signup";
import Review from "./components/Review/review";

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route exact path="/login" element={<Auth />} />
          <Route exact path="/signup" element={<Signup />} />
          <Route exact path="/dashboard" element={<Dashboard />} />
          <Route exact path="/add-review" element={<Review />} />
        </Routes>
      </Router>
      <ToastContainer />
    </div>
  );
}

export default App;
