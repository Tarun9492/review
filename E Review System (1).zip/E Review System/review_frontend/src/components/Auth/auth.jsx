import React, { Component } from "react";
import "./auth.css";
import "antd/dist/antd.css";
import * as antd from "antd";
import axios from "axios";
import { toast } from "react-toastify";

const Auth = () => {
  const onFinish = async (values) => {
    await axios
      .post("http://127.0.0.1:8000/api/login", {
        email: values.username,
        password: values.password,
      })
      .then((res) => {
        toast.success("Login successful");
        window.localStorage.setItem("accesstoken", res.data.data.access);
        window.localStorage.setItem("userid", res.data.data.user_id);
        window.localStorage.setItem("isadmin", res.data.data.admin);
        console.log(res.data.data.admin === true);
        setTimeout(() => {
          window.location.href = res.data.data.admin
            ? "/dashboard"
            : "/add-review";
        }, 1000);
      })
      .catch((err) => console.log(err));
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  return (
    <div className="login-page">
      <div className="login-box">
        <div className="illustration-wrapper">
          {/* <img
            src="https://mixkit.imgix.net/art/preview/mixkit-left-handed-man-sitting-at-a-table-writing-in-a-notebook-27-original-large.png?q=80&auto=format%2Ccompress&h=700"
            alt="Login"
          /> */}
          <img
            src="https://www.feedbackexpress.com/wp-content/uploads/2018/05/amazon-product-reviews-guide.jpg"
            alt="Login"
          />
        </div>
        <antd.Form
          name="login-form"
          initialValues={{ remember: true }}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
        >
          <p className="form-title">Welcome back</p>
          <p>Login to the Dashboard</p>
          <antd.Form.Item
            name="username"
            rules={[{ required: true, message: "Please input your email!" }]}
          >
            <antd.Input placeholder="Email" />
          </antd.Form.Item>

          <antd.Form.Item
            name="password"
            rules={[{ required: true, message: "Please input your password!" }]}
          >
            <antd.Input.Password placeholder="Password" />
          </antd.Form.Item>

          {/* <antd.Form.Item name="remember" valuePropName="checked">
            <antd.Checkbox>Remember me</antd.Checkbox>
          </antd.Form.Item> */}

          <div className="d-flex justify-content-end">
            <a href="/signup" className="mb-2">
              Sign up Here
            </a>
          </div>

          <antd.Form.Item>
            <antd.Button
              type="primary"
              htmlType="submit"
              className="login-form-button"
            >
              LOGIN
            </antd.Button>
          </antd.Form.Item>
        </antd.Form>
      </div>
    </div>
  );
};

export default Auth;
