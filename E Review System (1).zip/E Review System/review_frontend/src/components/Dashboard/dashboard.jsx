import React, { Component } from "react";
//import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import axios from "axios";
// import * as FileSaver from "file-saver";
// import * as XLSX from "xlsx";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

class Dashboard extends Component {
  state = {
    user: localStorage.getItem("userid"),
    admin: localStorage.getItem("isadmin"),
    reviews: [],
  };

  getReviews = async () => {
    const token = localStorage.getItem("accesstoken");
    await axios
      .get("http://localhost:8000/api/get-reviews", {
        headers: {
          Authorization: "Bearer " + token,
        },
      })
      .then((res) => this.setState({ reviews: res.data.data }))
      .catch((err) => console.log(err));
  };

  componentDidMount() {
    if (this.state.admin === "true") {
      this.getReviews();
    } else {
      this.logout();
    }
  }

  logout = () => {
    localStorage.removeItem("accesstoken");
    localStorage.removeItem("userid");
    localStorage.removeItem("admin");
    window.location.href = "/login";
  };
  render() {
    return (
      <div className="container px-5 py-2">
        <div className="row d-flex justify-content-end">
          <div className="col-1">
            <button className="btn btn-primary" onClick={(e) => this.logout()}>
              Logout
            </button>
          </div>
        </div>
        <div className="row mt-5 border-bottom">
          <div className="col-4">
            <h2>Reviews</h2>
          </div>
        </div>
        <div className="mt-4 p-3">
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell align="center">
                    <span className="font-weight-bold fs-16">Sl No</span>
                  </TableCell>
                  <TableCell align="center">
                    <span className="font-weight-bold fs-16">User Name</span>
                  </TableCell>
                  <TableCell align="center">
                    <span className="font-weight-bold fs-16">Product</span>
                  </TableCell>
                  <TableCell align="center">
                    <span className="font-weight-bold fs-16">Company</span>
                  </TableCell>
                  <TableCell align="center">
                    <span className="font-weight-bold fs-16">Price</span>
                  </TableCell>
                  <TableCell align="center">
                    <span className="font-weight-bold fs-16">
                      Date of Purchase
                    </span>
                  </TableCell>
                  <TableCell align="center">
                    <span className="font-weight-bold fs-16">
                      Rating (out of 5)
                    </span>
                  </TableCell>
                  <TableCell align="center">
                    <span className="font-weight-bold fs-16">Description</span>
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {this.state.reviews.map((review, indx) => (
                  <TableRow
                    key={review.id}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <TableCell align="center">{indx + 1}</TableCell>
                    <TableCell align="center">{review.user_name}</TableCell>
                    <TableCell align="center">{review.product}</TableCell>
                    <TableCell align="center">{review.company}</TableCell>
                    <TableCell align="center">{review.price}</TableCell>
                    <TableCell align="center">{review.purchase_date}</TableCell>
                    <TableCell align="center">{review.review}</TableCell>
                    <TableCell align="center">{review.description}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          {/* <div className="d-flex flex-wrap justify-content-start">
            {this.state.products.map((product) => (
              <div
                className="d-flex flex-column border mx-3 my-2"
                style={{
                  width: "350px",
                  height: "450px",
                }}
              >
                <img
                  width="350"
                  height="300"
                  src={"http://localhost:8000" + product.file.split(",")[0]}
                />
                <div className="d-flex flex-column p-1">
                  <h3>{product.name}</h3>
                </div>
              </div>
            ))}
          </div> */}
        </div>
      </div>
    );
  }
}

export default Dashboard;
