import React, { Component } from "react";
//import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from "reactstrap";
import axios from "axios";
// import * as FileSaver from "file-saver";
// import * as XLSX from "xlsx";
import "antd/dist/antd.css";
import * as antd from "antd";
import { DatePicker, Space } from "antd";
import { Rate } from "antd";
import { Input } from "antd";
import { toast } from "react-toastify";

const { TextArea } = Input;

class Review extends Component {
  state = {
    user: localStorage.getItem("userid"),
    admin: localStorage.getItem("isadmin"),
    reviews: [],
    rating: 1,
    purchase_date: "",
  };

  getReviews = async () => {
    const token = localStorage.getItem("accesstoken");
    await axios
      .get("http://localhost:8000/api/get-reviews", {
        headers: {
          Authorization: "Bearer " + token,
        },
      })
      .then((res) => this.setState({ reviews: res.data.data }))
      .catch((err) => console.log(err));
  };

  logout = () => {
    localStorage.removeItem("accesstoken");
    localStorage.removeItem("userid");
    localStorage.removeItem("admin");
    window.location.href = "/login";
  };
  onFinish = async (values) => {
    const reviewBody = {
      ...values,
      purchase_date: this.state.purchase_date,
      review: this.state.rating,
    };
    console.log(reviewBody);

    const token = localStorage.getItem("accesstoken");
    await axios
      .post("http://localhost:8000/api/create-review", reviewBody, {
        headers: {
          Authorization: "Bearer " + token,
        },
      })
      .then((res) => {
        if (res.data.success) {
          toast.success("Review Created");
          window.location.reload();
        } else {
          toast.warning("Error in review creation");
        }
      })
      .catch((err) => console.log(err));
  };

  onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  onDateChange = (date, dateString) => {
    this.setState({ purchase_date: dateString });
  };
  render() {
    return (
      <div className="container px-5 py-2">
        <div className="row d-flex justify-content-end">
          <div className="col-1">
            <button className="btn btn-primary" onClick={(e) => this.logout()}>
              Logout
            </button>
          </div>
        </div>
        <div className="row mt-5 border-bottom">
          <div className="col-4">
            <h2>Create a review</h2>
          </div>
        </div>
        <div className="mt-2 p-1 d-flex justify-content-center">
          <antd.Form
            name="login-form"
            initialValues={{ remember: true }}
            onFinish={this.onFinish}
            onFinishFailed={this.onFinishFailed}
          >
            {/* <p className="form-title">Create a review</p> */}
            <antd.Form.Item
              name="user_name"
              rules={[{ required: true, message: "Please input your name!" }]}
            >
              <antd.Input
                placeholder="User Name"
                style={{
                  height: "45px",
                }}
              />
            </antd.Form.Item>

            <antd.Form.Item
              name="product"
              rules={[
                { required: true, message: "Please input product name!" },
              ]}
            >
              <antd.Input
                placeholder="Product"
                style={{
                  height: "45px",
                }}
              />
            </antd.Form.Item>

            <antd.Form.Item name="company">
              <antd.Input
                placeholder="Company"
                style={{
                  height: "45px",
                }}
              />
            </antd.Form.Item>

            <antd.Form.Item name="price">
              <antd.Input
                placeholder="Price"
                style={{
                  height: "45px",
                }}
              />
            </antd.Form.Item>

            <antd.Form.Item name="purchase_date">
              <DatePicker
                onChange={this.onDateChange}
                style={{
                  height: "45px",
                  width: "360px",
                }}
              />
            </antd.Form.Item>

            <antd.Form.Item
              name="description"
              rules={[{ required: true, message: "Please input your review!" }]}
            >
              {/* <antd.Input
                placeholder="Description"
                style={{
                  height: "45px",
                }}
              /> */}
              <TextArea placeholder="Description" rows={4} />
            </antd.Form.Item>

            <div className="d-flex align-items-center justify-content-between px-2 mb-4">
              <p className="fs-16 mb-0">Rating</p>
              <Rate onChange={(value) => this.setState({ rating: value })} />
            </div>

            {/* <antd.Form.Item name="remember" valuePropName="checked">
            <antd.Checkbox>Remember me</antd.Checkbox>
          </antd.Form.Item> */}

            <antd.Form.Item>
              <antd.Button
                type="primary"
                htmlType="submit"
                className="login-form-button"
              >
                Create Review
              </antd.Button>
            </antd.Form.Item>
          </antd.Form>
        </div>
      </div>
    );
  }
}

export default Review;
