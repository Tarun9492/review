import React, { Component } from "react";
import "./signup.css";
import "antd/dist/antd.css";
import * as antd from "antd";
import axios from "axios";
import { toast } from "react-toastify";

const Signup = () => {
  const onFinish = async (values) => {
    if (values.password === values.confirm_password) {
      await axios
        .post("http://127.0.0.1:8000/api/signup", {
          email: values.username,
          password: values.password,
          first_name: values.first_name,
          last_name: values.last_name,
        })
        .then((res) => {
          toast.success("Signup successful");
          setTimeout(() => {
            window.location.href = "/login";
          }, 1500);
        })
        .catch((err) => {
          toast.warning("Signup Failed");
        });
    } else {
      toast.warning("Passwords do not match");
    }
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  return (
    <div className="login-page">
      <div className="login-box">
        <div className="illustration-wrapper">
          {/* <img
            src="https://mixkit.imgix.net/art/preview/mixkit-left-handed-man-sitting-at-a-table-writing-in-a-notebook-27-original-large.png?q=80&auto=format%2Ccompress&h=700"
            alt="Login"
          /> */}
          <img
            src="https://www.feedbackexpress.com/wp-content/uploads/2018/05/amazon-product-reviews-guide.jpg"
            alt="Login"
          />
        </div>
        <antd.Form
          name="login-form"
          initialValues={{ remember: true }}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
        >
          <p className="form-title">Welcome</p>
          <p>Signup to the platform</p>
          <antd.Form.Item
            name="first_name"
            rules={[
              { required: true, message: "Please input your first name!" },
            ]}
          >
            <antd.Input
              placeholder="First Name"
              style={{
                height: "45px",
              }}
            />
          </antd.Form.Item>

          <antd.Form.Item
            name="last_name"
            rules={[
              { required: true, message: "Please input your last name!" },
            ]}
          >
            <antd.Input
              placeholder="Last Name"
              style={{
                height: "45px",
              }}
            />
          </antd.Form.Item>

          <antd.Form.Item
            name="username"
            rules={[{ required: true, message: "Please input your email!" }]}
          >
            <antd.Input placeholder="Email" />
          </antd.Form.Item>

          <antd.Form.Item
            name="password"
            rules={[{ required: true, message: "Please input your password!" }]}
          >
            <antd.Input.Password placeholder="Password" />
          </antd.Form.Item>

          <antd.Form.Item
            name="confirm_password"
            rules={[
              { required: true, message: "Please confirm your password!" },
            ]}
          >
            <antd.Input.Password placeholder="Confirm Password" />
          </antd.Form.Item>

          {/* <antd.Form.Item name="remember" valuePropName="checked">
            <antd.Checkbox>Remember me</antd.Checkbox>
          </antd.Form.Item> */}

          <div className="d-flex justify-content-end">
            <a href="/login" className="mb-2">
              Login Here
            </a>
          </div>

          <antd.Form.Item>
            <antd.Button
              type="primary"
              htmlType="submit"
              className="login-form-button"
            >
              SIGN UP
            </antd.Button>
          </antd.Form.Item>
        </antd.Form>
      </div>
    </div>
  );
};

export default Signup;
